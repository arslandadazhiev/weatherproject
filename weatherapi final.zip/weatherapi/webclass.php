<?php 
class SiteClass {
	private $conn = ""; 	
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","mydata");
	}	

				function getWeatherData() {
					
                    $citystring=$_POST['name'];
					if(!empty($citystring)){
						
						if (str_contains($citystring, ',')) {
							$pieces = explode(",", $citystring);
						}
						if (str_contains($citystring, ' ')) {
							$pieces = explode(" ", $citystring);
						}
					}
                    
					$owm_key = '2b53c8e129c45e418abf014aeedba6e7';
					foreach ($pieces as $city) {
						$apiUrl = "http://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$owm_key}&units=metric";
						$response = file_get_contents($apiUrl);
						$data = json_decode($response, true);
				
						if ($data['cod'] == 200) {
							$temperature = $data['main']['temp'];
							$weather = $data['weather'][0]['description'];
							$precipitation = $data['clouds']['all'];
							$windSpeed = $data['wind']['speed'];
							echo "<table class=\"table\">
							<thead>
								<tr>
								<th scope=\"col\">Погода</th>
								<th scope=\"col\">Температура</th>
								<th scope=\"col\">Погодные условия</th>
								<th scope=\"col\">Количество осадков </th>
								<th scope=\"col\">Скорость ветра </th>
								</tr>
							</thead>
							<tbody>
								<tr>
								<th scope=\"row\">{$city}</th>
								<td>{$temperature}°C</td>
								<td>{$weather}</td>
								<td>{$precipitation}</td>
								<td>{$windSpeed} м/с</td>
								</tr>
							</tbody>
							</table>  ";     
						} else {
							echo "Не удалось получить данные о погоде для города {$city}\n";
						}
				
						echo "\n";
					}

				}
				
}

 ?>