 
<!doctype html>
<html lang="en" data-bs-theme="auto">
<head>
    <script src="assets/js/color-modes.js"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Hugo 0.115.4">
        <title>Задание с API погоды</title>
        <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
        <link href="jqui/jquery-ui.css" rel="stylesheet">
    <script src="js/jquery-3.7.1.js"></script>
    <script src="jqui/jquery-ui.js"></script>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="sign-in.css" rel="stylesheet">
</head>
<script>
$(function(){
	$('#table').load('table.php');	
});
</script>
 
 
<main class=" w-50 m-auto">
<form action="" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">Введите города</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Имя">
  </div>
  <button type="submit" id="sbmbutton" class="btn btn-primary">Узнать погоду</button>
</form>
<?php
//$sc->getWeatherData();
?>
<div id="table"></div>
</main>
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
<script>

  $( "form" ).on("submit", function(event) {
      event.preventDefault();
      let namee= $('#name').val();
        $.post('table.php',$(this).serialize(), function(data){
          $('#weather').load('table.php');
          $('#table').html(data);	
        });
    } );
</script>
    </body>
</html>
